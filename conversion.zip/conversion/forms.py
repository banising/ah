from bs4 import BeautifulSoup

def parse_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')

    # Find all <form> elements
    forms = soup.find_all('form')

    for form in forms:
        # Find all input elements within the form with a 'name' attribute
        input_elements = form.find_all('input', {'name': True})

        for input_element in input_elements:
            # Extract and print the 'name' attribute value
            name_value = input_element['name']
            print(f'name="{name_value}"')

if __name__ == "__main__":
    # Ask the user for the HTML file name
    html_file_name = input("Enter the name of the HTML file (e.g., index.html): ")

    try:
        # Read HTML content from the specified file
        with open(html_file_name, 'r', encoding='utf-8') as file:
            html_content = file.read()

        # Parse the HTML content and print the name values inside forms
        parse_html(html_content)

    except FileNotFoundError:
        print(f"Error: File '{html_file_name}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")
